list=["haider", "haider", "umer", "usman", "usman"]
list.remove("haider")
list.remove("usman")
print(list)